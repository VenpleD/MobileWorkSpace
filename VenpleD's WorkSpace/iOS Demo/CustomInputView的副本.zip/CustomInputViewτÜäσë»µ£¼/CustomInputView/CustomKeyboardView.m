//
//  CustomKeyboardView.m
//  CustomInputView
//
//  Created by 段文菩 on 2017/11/14.
//  Copyright © 2017年 段文菩. All rights reserved.
//

#import "CustomKeyboardView.h"

#define SCREEN_WIDTH          [[UIScreen mainScreen] bounds].size.width
//屏幕高
#define SCREEN_HEIGHT ([[UIScreen mainScreen] bounds].size.height)

#define RGB_TO_UICOLOR(r, g, b)                     [UIColor colorWithRed:((r) / 255.0) green:((g) / 255.0) blue:((b) / 255.0) alpha:1.0]


@interface TextImageView : UIImageView

@property (nonatomic, strong) NSString *text;

@property (nonatomic, strong) UILabel *label;

@end;

@implementation TextImageView

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self configSubviews];
    }
    return self;
}

- (void)configSubviews {
    _label = [[UILabel alloc] init];
    [_label setBounds:CGRectMake(0, 0, CGRectGetWidth(self.frame), CGRectGetWidth(self.frame))];
    [_label setCenter:CGPointMake(self.center.x, self.center.y / 2)];
    [_label setTextAlignment:NSTextAlignmentCenter];
    [_label setFont:[UIFont systemFontOfSize:26.f]];
    [_label setTextColor:[UIColor blackColor]];
    [self addSubview:_label];
}

- (void)setText:(NSString *)text {
    _text = text;
    [self.label setCenter:CGPointMake(self.frame.size.width / 2, self.frame.size.height / 4)];
    [self.label setText:_text];
}

@end

@interface CustomKeyboardView ()

{
///    用户看到的键的高度
    CGFloat _showKeyHeight;
    
///    用户看到的键的宽度
    CGFloat _showKeyWidth;
    
    ///字母view的高度
    CGFloat _lettersViewHeight;
    
    CGFloat _numbersViewHeight;
    
    CGFloat _marginTopBottom;
    
    ///行间距
    CGFloat _lineInterval;
    
    ///小写字母图片名称
    NSString *_lowercaseImageName;
    
    ///大写字母图片名称
    NSString *_captialImageName;
    
    ///数字图片名称
    NSString *_numbersImageName;
    
    ///触摸的每个键的宽度
    CGFloat _perKeyWidth;
    
    ///自身view的高度
    CGFloat _selfHeight;
    
}

///小写字母的字典
@property (nonatomic, strong) NSMutableDictionary *lowercaseDict;

///大写字母的字典
@property (nonatomic, strong) NSMutableDictionary *uppercaseDict;

///每个键的高度
@property (nonatomic, assign) CGFloat perKeyHeight;

///切换大小写的按钮
@property (nonatomic, strong) UIButton *switchButton;

///回退键
@property (nonatomic, strong) UIButton *backspaceButton;

///确认键
@property (nonatomic, strong) UIButton *enterButton;

@property (nonatomic, strong) UIView *backgroundView;

@property (nonatomic, strong) UIImageView *numbersImageView;

@property (nonatomic, strong) UIImageView *lettersImageView;

@property (nonatomic, strong) TextImageView *textImageView;

@end

///距离屏幕左右边缘的间距,量过了，所有的设备距离左右边缘都是3像素
static CGFloat MarginLeftRight = 3.f;

@implementation CustomKeyboardView

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self prepareBaseViewParams];
        [self prepareCoordinate];
        [self configSubview];
    }
    return self;
}

#pragma mark - 准备初始化工作，主要是根据屏幕的不同进行尺寸的设置
- (void)prepareBaseViewParams {
/**
 *  根据屏幕不同显示不同的图片，分为三类
 *  1，5s以前的是一种，2，4.7寸屏幕的 3.plus屏幕的
 *
 */
    if (SCREEN_HEIGHT <= 568.0) {
//        4.7以下的
        _showKeyHeight = 39.f;
        _lettersViewHeight = 177.f;
        _lineInterval = 15.f;
        _marginTopBottom = 11.f;
        _numbersImageName = @"img_numbers_568";
        _captialImageName = @"img_uppercase_568";
        _lowercaseImageName = @"img_lowercase_568";
        _perKeyWidth = 32.f;
        _showKeyWidth = 26;
    } else if (SCREEN_HEIGHT >= 736.0 && SCREEN_WIDTH >= 414.f) {
//        plus以上的
        _showKeyHeight = 46.f;
        _lettersViewHeight = 178.f;
        _lineInterval = 10.f;
        _marginTopBottom = 8.f;
        _numbersImageName = @"img_numbers_736";
        _captialImageName = @"img_uppercase_736";
        _lowercaseImageName = @"img_lowercase_736";
        _perKeyWidth = 41.4f;
        _showKeyWidth = 35.f;
    } else {
//        4.7的 iPhone x
        _showKeyHeight = 43.f;
        _lettersViewHeight = 173.f;
        _lineInterval = 11.f;
        _marginTopBottom = 8.f;
        _numbersImageName = @"img_numbers_667";
        _captialImageName = @"img_uppercase_667";
        _lowercaseImageName = @"img_lowercase_667";
        _perKeyWidth = 37.5f;
        _showKeyWidth = 31.5f;
    }
    
    _selfHeight = _lettersViewHeight + _showKeyHeight * 2 + _marginTopBottom + MarginLeftRight;
    self.frame = CGRectMake(0, SCREEN_HEIGHT - _selfHeight, SCREEN_WIDTH, _selfHeight);
}

#pragma mark - 配置子视图
- (void)configSubview {
    [self addSubview:self.backgroundView];
    
    [self.backgroundView addSubview:self.lettersImageView];
    [self.backgroundView addSubview:self.numbersImageView];
    [self.backgroundView addSubview:self.enterButton];
    [self.backgroundView addSubview:self.backspaceButton];
    [self.backgroundView addSubview:self.switchButton];
    [self.backgroundView addSubview:self.textImageView];
}

#pragma mark - 准备每个按钮的左边，并且将每个按钮的左边xy作为Key，内容作为value添加到字典当中
- (void)prepareCoordinate {
    [self initContainer];
    
    _perKeyHeight = _showKeyHeight + _lineInterval;
    
//    添加数字到字典当中
    for (NSInteger i = 1; i < 11; i ++) {
        NSString *value;
        if (i == 10) {
            value = [NSString stringWithFormat:@"%d",0];
        } else {
            value = [NSString stringWithFormat:@"%d",i];
        }
        [self.lowercaseDict setObject:value forKey:[NSString stringWithFormat:@"%f%f",_perKeyWidth * (i - 1),0.f]];
        [self.uppercaseDict setObject:value forKey:[NSString stringWithFormat:@"%f%f",_perKeyWidth * (i - 1),0.f]];
    }
    
//    添加字母到字典当中
    NSArray *tempLowerCaseArray = @[@"q",@"w",@"e",@"r",@"t",@"y",@"u",@"i",@"o",@"p",@"a",@"s",@"d",@"f",@"g",@"h",@"j",@"k",@"l",@"z",@"x",@"c",@"v",@"b",@"n",@"m"];

    for (NSInteger i = 1; i < tempLowerCaseArray.count + 1; i++) {
        @autoreleasepool {
            CGFloat xCoordinate;
            CGFloat yCoordinate;
            if (i <= 10) {
                xCoordinate = _perKeyWidth * ((i - 1) % 10);
                yCoordinate = _marginTopBottom + _showKeyHeight;
                
            } else if (i > 10 && i <= 19) {
                xCoordinate = _perKeyWidth / 2 + _perKeyWidth * (i % 10 - 1);
                yCoordinate = _perKeyHeight * 1 + _marginTopBottom + _showKeyHeight;
                
            } else {
                xCoordinate = _perKeyWidth / 2 + _perKeyWidth * ((i % 10) + 1);
                yCoordinate = _perKeyHeight * 2 + _marginTopBottom + _showKeyHeight;
            }
            
//            将xy坐标拼接作为字典的key值，value为对应的字母
            NSString *coordinateKey = [NSString stringWithFormat:@"%f%f", xCoordinate, yCoordinate];
            [self.lowercaseDict setValue:tempLowerCaseArray[i - 1] forKey:coordinateKey];
            [self.uppercaseDict setValue:[tempLowerCaseArray[i - 1] uppercaseString] forKey:coordinateKey];
        }
    }
    
    for (NSInteger i = 1; i < tempLowerCaseArray.count + 1; i++) {
        @autoreleasepool {
            CGFloat xCoordinate;
            CGFloat yCoordinate;
            if (i <= 10) {
                xCoordinate = _perKeyWidth * ((i - 1) % 10);
                yCoordinate = _marginTopBottom + _showKeyHeight;
                
            } else if (i > 10 && i <= 19) {
                xCoordinate = _perKeyWidth / 2 + _perKeyWidth * (i % 10 - 1);
                yCoordinate = _perKeyHeight * 1 + _marginTopBottom + _showKeyHeight;
                
            } else {
                xCoordinate = _perKeyWidth / 2 + _perKeyWidth * ((i % 10) + 1);
                yCoordinate = _perKeyHeight * 2 + _marginTopBottom + _showKeyHeight;
            }
            NSString *coordinateKey = [NSString stringWithFormat:@"%f%f", xCoordinate, yCoordinate];
            [self.lowercaseDict setValue:tempLowerCaseArray[i - 1] forKey:coordinateKey];
            [self.uppercaseDict setValue:[tempLowerCaseArray[i - 1] uppercaseString] forKey:coordinateKey];
        }
    }

}

- (void)willShowRemoteKeyboardWindow {
    if (self.tapDelegate && [self.tapDelegate respondsToSelector:@selector(customKeyboardViewShouldDidEditing:)]) {
        __weak typeof(self) weakSelf = self;
        [self.tapDelegate customKeyboardViewShouldDidEditing:weakSelf];
    }
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    
    UITouch *touch = [touches anyObject];
    CGPoint touchPoint = [touch locationInView:self];
    CGFloat yTouch = touchPoint.y;
    if (yTouch < _selfHeight - _showKeyHeight - _lineInterval) {
        [self handleTouchAreaWithXCoordinate:touchPoint.x yCoordinate:yTouch];
    }
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self.textImageView setFrame:CGRectMake(MAXFLOAT, MAXFLOAT, CGRectGetWidth(self.textImageView.frame), CGRectGetHeight(self.textImageView.frame))];
}

#pragma mark 根据用户点击的左边来确定他的区域所在的确切坐标，就是逆向推出字典当中已有的坐标Key值
- (void)handleTouchAreaWithXCoordinate:(CGFloat)xCoordinate yCoordinate:(CGFloat)yCoordinate {
    CGFloat resultY;
    CGFloat resultX;
    if (yCoordinate <= _marginTopBottom + _showKeyHeight) {
        NSInteger multiple = xCoordinate / _perKeyWidth;
        resultX =multiple * _perKeyWidth;
        resultY = 0.f;
    } else {
        yCoordinate -= (_marginTopBottom + _showKeyHeight);
        NSInteger line = yCoordinate / self.perKeyHeight;
        resultY = line * self.perKeyHeight;
        
        if (line >= 1) {
            NSInteger multiple = (xCoordinate - _perKeyWidth / 2) / _perKeyWidth;
            resultX = multiple * _perKeyWidth + _perKeyWidth / 2;
        } else {
            NSInteger multiple = xCoordinate / _perKeyWidth;
            resultX =multiple * _perKeyWidth;
        }
        resultY += (_marginTopBottom + _showKeyHeight);
    }

//  以下部分是这个项目里面最耗时间的，主要是UI部分的渲染和更改，比较浪费时间，其他的都还不错，不过没有跟for循环创建36个button那种进行对比。
    NSString *coordinateKey = [NSString stringWithFormat:@"%f%f", resultX, resultY];
    if ([self.lowercaseDict.allKeys containsObject:coordinateKey]) {
        [self.textImageView setFrame:CGRectMake(resultX - MarginLeftRight * 2, resultY - _showKeyHeight, CGRectGetWidth(self.textImageView.frame), CGRectGetHeight(self.textImageView.frame))];
        [self handleTapContentWithCoordinateKey:coordinateKey];
    }
}

#pragma mark - 根据坐标key值来进行textfield的赋值，以及代理的调用
- (void)handleTapContentWithCoordinateKey:(NSString *)coordinateKey {
    NSString *resultContent;
    if (self.switchButton.selected) {
        resultContent = self.uppercaseDict[coordinateKey];
    } else {
        resultContent = self.lowercaseDict[coordinateKey];
    }
    [self.textImageView setText:resultContent];
    [self handleChangeCharactersDelegateWithReplacementString:resultContent];
}

#pragma mark - 切换大小写键盘
- (void)switchCaptialOrLowercase {
    self.switchButton.selected = !self.switchButton.selected;
    self.lettersImageView.highlighted = !self.lettersImageView.highlighted;
}

#pragma mark - 退格键的点击事件
- (void)backspaceAction {
    if (self.tapDelegate && [self.tapDelegate respondsToSelector:@selector(customKeyboardViewShouldClear:)]) {
        __weak typeof(self) weakSelf = self;
        [self.tapDelegate customKeyboardViewShouldClear:weakSelf];
    }
    [self handleChangeCharactersDelegateWithReplacementString:@""];
}

#pragma mark - 确认键的点击事件
- (void)enterAction {
    if (self.tapDelegate && [self.tapDelegate respondsToSelector:@selector(customKeyboardViewShouldReturn:)]) {
        __weak typeof(self) weakSelf = self;
        [self.tapDelegate customKeyboardViewShouldReturn:weakSelf];
    }
    
}

#pragma mark - 处理shouldChangeCharactersInRange代理方法的公共处理逻辑
- (void)handleChangeCharactersDelegateWithReplacementString:(NSString *)replacementString {
    if (self.tapDelegate && [self.tapDelegate respondsToSelector:@selector(customKeyboardView:replacementString:)]) {
        __weak typeof(self) weakSelf = self;
        [self.tapDelegate customKeyboardView:weakSelf replacementString:replacementString];
    }
}

#pragma mark - 初始化容器属性
- (void)initContainer {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(willShowRemoteKeyboardWindow) name:UIKeyboardWillShowNotification object:nil];
    _lowercaseDict = [NSMutableDictionary dictionary];
    _uppercaseDict = [NSMutableDictionary dictionary];
}

#pragma mark - 下面是懒加载视图和部分属性
- (UIButton *)switchButton {
    if (!_switchButton) {
        _switchButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_switchButton setFrame:CGRectMake(MarginLeftRight, CGRectGetMinY(self.backspaceButton.frame), _showKeyHeight, _showKeyHeight)];
        [_switchButton setBackgroundImage:[UIImage imageNamed:@"btn_switchNormal"] forState:UIControlStateNormal];
        [_switchButton setBackgroundImage:[UIImage imageNamed:@"btn_switchSelected"] forState:UIControlStateSelected];
        [_switchButton addTarget:self action:@selector(switchCaptialOrLowercase) forControlEvents:UIControlEventTouchUpInside];
    }
    return _switchButton;
}

- (UIButton *)backspaceButton {
    if (!_backspaceButton) {
        _backspaceButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_backspaceButton setFrame:CGRectMake(SCREEN_WIDTH - _showKeyHeight - MarginLeftRight, CGRectGetMinY(self.enterButton.frame) - _showKeyHeight - _lineInterval - 1, _showKeyHeight, _showKeyHeight)];
        [_backspaceButton setBackgroundImage:[UIImage imageNamed:@"btn_backspaceNormal"] forState:UIControlStateNormal];
        [_backspaceButton setBackgroundImage:[UIImage imageNamed:@"btn_backspaceSelected"] forState:UIControlStateHighlighted];
        UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(backspaceAction)];
        [_backspaceButton addGestureRecognizer:longPress];
        [_backspaceButton addTarget:self action:@selector(backspaceAction) forControlEvents:UIControlEventTouchUpInside];
    }
    return _backspaceButton;
}

- (UIButton *)enterButton {
    if (!_enterButton) {
        _enterButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_enterButton setFrame:CGRectMake(MarginLeftRight, _selfHeight - MarginLeftRight - _showKeyHeight, SCREEN_WIDTH - MarginLeftRight * 2, _showKeyHeight)];
        [_enterButton setBackgroundColor:RGB_TO_UICOLOR(21, 125, 251)];
        [_enterButton setTitle:@"提交" forState:UIControlStateNormal];
        [_enterButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_enterButton addTarget:self action:@selector(enterAction) forControlEvents:UIControlEventTouchUpInside];
        [_enterButton.layer setMasksToBounds:YES];
        [_enterButton.layer setCornerRadius:5.f];
    }
    return _enterButton;
}

- (TextImageView *)textImageView {
    if (!_textImageView) {
        _textImageView = [[TextImageView alloc] initWithFrame:CGRectMake(MAXFLOAT, MAXFLOAT, _perKeyWidth + MarginLeftRight * 4, _showKeyHeight * 2 + _lineInterval)];
        [_textImageView setImage:[UIImage imageNamed:@"img_keySlected"]];
    }
    return _textImageView;
}

- (UIImageView *)numbersImageView {
    if (!_numbersImageView) {
        _numbersImageView = [[UIImageView alloc] init];
        [_numbersImageView setFrame:CGRectMake(0, 0, SCREEN_WIDTH, _showKeyHeight + _marginTopBottom)];
        [_numbersImageView setImage:[UIImage imageNamed:_numbersImageName]];
    }
    return _numbersImageView;
}

- (UIImageView *)lettersImageView {
    if (!_lettersImageView) {
        _lettersImageView = [[UIImageView alloc] init];
        [_lettersImageView setImage:[UIImage imageNamed:_lowercaseImageName]];
        [_lettersImageView setHighlightedImage:[UIImage imageNamed:_captialImageName]];
        [_lettersImageView setFrame:CGRectMake(0, _showKeyHeight + _marginTopBottom, SCREEN_WIDTH, _lettersViewHeight)];
    }
    return _lettersImageView;
}

- (UIView *)backgroundView {
    if (!_backgroundView) {
        _backgroundView = [[UIView alloc] init];
        [_backgroundView setFrame:CGRectMake(0, 0, SCREEN_WIDTH, _selfHeight)];
        [_backgroundView setBackgroundColor:RGB_TO_UICOLOR(217, 220, 222)];
    }
    return _backgroundView;
}

@end
