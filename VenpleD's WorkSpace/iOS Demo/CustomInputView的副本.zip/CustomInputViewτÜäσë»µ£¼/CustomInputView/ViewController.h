//
//  ViewController.h
//  CustomInputView
//
//  Created by 段文菩 on 2017/11/9.
//  Copyright © 2017年 段文菩. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

