
//
//  DifferentKeyboardTextField.m
//  CustomInputView
//
//  Created by 段文菩 on 2017/11/16.
//  Copyright © 2017年 段文菩. All rights reserved.
//

#import "DifferentKeyboardTextField.h"
#import "CustomKeyboardView.h"

@interface DifferentKeyboardTextField ()<tapDelegate>

@property (nonatomic, strong) NSMutableString *textMutableString;

@end

@implementation DifferentKeyboardTextField

- (void)dealloc {
    
}

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        CustomKeyboardView *keyboardView = [[CustomKeyboardView alloc] init];
        self.inputView = keyboardView;
        [keyboardView setTapDelegate:self];
    }
    return self;
}

- (void)customKeyboardView:(CustomKeyboardView *)keyboardView replacementString:(NSString *)string {
    void (^assignText)() = ^() {
        [self.textMutableString setString:self.text];
        [self.textMutableString appendString:string];
        [self setText:self.textMutableString];
    };
    if (self.ylDelegate && [self.ylDelegate respondsToSelector:@selector(yl_textField:shouldChangeCharactersInRange:replacementString:)]) {
        __weak typeof(self) weakSelf = self;
        BOOL isChange = [self.ylDelegate yl_textField:weakSelf shouldChangeCharactersInRange:NSMakeRange(self.text.length, string.length) replacementString:string];
        if (isChange) {
            assignText();
        }
    } else {
        assignText();
    }
}

- (void)customKeyboardViewShouldClear:(CustomKeyboardView *)keyboardView {
    void (^assignText)() = ^() {
        if (self.text.length) {
            [self.textMutableString setString:self.text];
            [self.textMutableString deleteCharactersInRange:NSMakeRange(self.text.length - 1, 1)];
            [self setText:self.textMutableString];
        }
    };
    if (self.ylDelegate && [self.ylDelegate respondsToSelector:@selector(yl_textFieldShouldClear:)]) {
        __weak typeof(self) weakSelf = self;
        BOOL isChange = [self.ylDelegate yl_textFieldShouldClear:weakSelf];
        if (isChange) {
            assignText();
        }
    } else {
        assignText();
    }
}

- (void)customKeyboardViewShouldReturn:(CustomKeyboardView *)keyboardView {
    if (self.ylDelegate && [self.ylDelegate respondsToSelector:@selector(yl_textFieldShouldReturn:)]) {
        __weak typeof(self) weakSelf = self;
        [self.ylDelegate yl_textFieldShouldReturn:weakSelf];
    }
}

- (void)customKeyboardViewShouldDidEditing:(CustomKeyboardView *)keyboardView {
    if (self.ylDelegate && [self.ylDelegate respondsToSelector:@selector(yl_textFieldShouldDidEditing:)]) {
        __weak typeof(self) weakSelf = self;
        [self.ylDelegate yl_textFieldShouldDidEditing:weakSelf];
    }
}

- (NSMutableString *)textMutableString {
    if (!_textMutableString) {
        _textMutableString = [NSMutableString string];
    }
    return _textMutableString;
}


@end
