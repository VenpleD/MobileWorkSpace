//
//  ViewController.m
//  CustomInputView
//
//  Created by 段文菩 on 2017/11/9.
//  Copyright © 2017年 段文菩. All rights reserved.
//

#import "ViewController.h"
#import "CustomKeyboardView.h"
#import "DifferentKeyboardTextField.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    DifferentKeyboardTextField *textField = [[DifferentKeyboardTextField alloc] init];
    [textField setBounds:CGRectMake(0, 0, 200, 50)];
    [textField setCenter:CGPointMake(self.view.center.x, self.view.center.y - 80)];
    [textField setBorderStyle:UITextBorderStyleLine];
    [self.view addSubview:textField];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
