//
//  CustomKeyboardView.h
//  CustomInputView
//
//  Created by 段文菩 on 2017/11/14.
//  Copyright © 2017年 段文菩. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol tapDelegate;

@interface CustomKeyboardView : UIView

@property (nonatomic, weak) id<tapDelegate> tapDelegate;


@end

@protocol tapDelegate <NSObject>

/**
 *  点击按键就会回调此方法
 *  @param keyboardView 键盘所在视图
 *  @param string   每次输入的内容字符串
 */
- (void)customKeyboardView:(CustomKeyboardView *)keyboardView replacementString:(NSString *)string;

/**
 *  点击删除按钮回调的方法
 */
- (void)customKeyboardViewShouldClear:(CustomKeyboardView *)keyboardView;

/**
 *  点击确认按钮回调的方法
 */
- (void)customKeyboardViewShouldReturn:(CustomKeyboardView *)keyboardView;

- (void)customKeyboardViewShouldDidEditing:(CustomKeyboardView *)keyboardView;

@end
