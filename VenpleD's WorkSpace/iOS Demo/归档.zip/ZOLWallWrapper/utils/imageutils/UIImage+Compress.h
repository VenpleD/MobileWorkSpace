//
//  UIColor+Compress.h
//  PPG
//
//  Created by zhujinhui on 15-1-2.
//  Copyright (c) 2015年 zhujinhui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage(Compress)



- (UIImage*)scaledToSize:(CGSize)newSize;


-(UIImage *)scaleto:(float)scaleSize;

@end
