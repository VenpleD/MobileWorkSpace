//
//  Image.m
//  ZOLWallWrapper
//
//  Created by zhujinhui on 14-12-29.
//  Copyright (c) 2014年 zhujinhui. All rights reserved.
//

#import "Image.h"

@implementation Image

@end
