//
//  Image.h
//  ZOLWallWrapper
//
//  Created by zhujinhui on 14-12-29.
//  Copyright (c) 2014年 zhujinhui. All rights reserved.
//

#import "BaseModel.h"

@interface Image : BaseModel

@property (nonatomic, copy) NSString *gId;
@property (nonatomic, copy) NSString *gName;
@property (nonatomic, copy) NSString *imgUrl;
@property (nonatomic, copy) NSString *pId;

@end
