//
//  MenuViewController.h
//  ZOLWallWrapper
//
//  Created by zhujinhui on 14-12-9.
//  Copyright (c) 2014年 zhujinhui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuViewController : UIViewController

@end
