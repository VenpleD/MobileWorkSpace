//
//  SearchHistoryItemCell.m
//  ZOLWallWrapper
//
//  Created by zhujinhui on 15-1-4.
//  Copyright (c) 2015年 zhujinhui. All rights reserved.
//

#import "SearchHistoryItemCell.h"

@interface SearchHistoryItemCell (){
}

@end


@implementation SearchHistoryItemCell


- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
