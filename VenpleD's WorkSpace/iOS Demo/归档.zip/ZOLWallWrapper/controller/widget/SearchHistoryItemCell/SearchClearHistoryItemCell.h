//
//  SearchClearHistoryItemCell.h
//  ZOLWallWrapper
//
//  Created by zhujinhui on 15/2/6.
//  Copyright (c) 2015年 zhujinhui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchClearHistoryItemCell : UITableViewCell{
    
}

@property (nonatomic, weak) IBOutlet UIButton *clearCacheButton;

@end
