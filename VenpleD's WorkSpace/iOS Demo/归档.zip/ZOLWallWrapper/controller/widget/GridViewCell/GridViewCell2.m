//
//  GridViewCell2.m
//  ZOLWallWrapper
//
//  Created by zhujinhui on 15-1-7.
//  Copyright (c) 2015年 zhujinhui. All rights reserved.
//

#import "GridViewCell2.h"

@implementation GridViewCell2

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


@end
