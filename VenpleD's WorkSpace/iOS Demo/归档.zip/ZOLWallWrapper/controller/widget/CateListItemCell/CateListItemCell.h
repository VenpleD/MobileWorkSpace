//
//  CateListItemCell.h
//  ZOLWallWrapper
//
//  Created by zhujinhui on 14-12-31.
//  Copyright (c) 2014年 zhujinhui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CateListItemCell : UITableViewCell


@property (nonatomic, retain) IBOutlet UILabel *titleLabel;
//@property (nonatomic, retain) UILabel *titleLabel;


@end
