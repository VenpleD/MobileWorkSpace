//
//  CategoryViewController.h
//  ZOLWallWrapper
//
//  Created by zhujinhui on 14-12-24.
//  Copyright (c) 2014年 zhujinhui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Classification.h"

@interface SubCategoryViewController : Controller

@property (nonatomic, strong) Classification *category;

@end
