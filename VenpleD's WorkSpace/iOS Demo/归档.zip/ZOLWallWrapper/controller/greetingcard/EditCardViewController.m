//
//  EditCardViewController.m
//  ZOLWallWrapper
//
//  Created by zhujinhui on 15/2/8.
//  Copyright (c) 2015年 zhujinhui. All rights reserved.
//

#import "EditCardViewController.h"

@interface EditCardViewController ()

@end

@implementation EditCardViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title = @"贺卡编辑器";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
