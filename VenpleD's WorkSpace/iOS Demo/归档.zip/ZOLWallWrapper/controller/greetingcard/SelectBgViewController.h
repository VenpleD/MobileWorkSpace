//
//  SelectBgViewController.h
//  ZOLWallWrapper
//
//  Created by zhujinhui on 15/2/8.
//  Copyright (c) 2015年 zhujinhui. All rights reserved.
//

#import "Controller.h"

@interface SelectBgViewController : Controller

@end
