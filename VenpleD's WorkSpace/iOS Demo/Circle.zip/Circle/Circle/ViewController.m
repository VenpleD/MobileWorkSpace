//
//  ViewController.m
//  Circle
//
//  Created by 段文菩 on 2018/1/30.
//  Copyright © 2018年 段文菩. All rights reserved.
//

#import "ViewController.h"
#import "NextViewController.h"
#import "Person.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSMutableArray *array = [NSMutableArray array];
    static int a = 0;
    [NSTimer scheduledTimerWithTimeInterval:1 repeats:YES block:^(NSTimer * _Nonnull timer) {
        if (a == 10) {
            [timer invalidate];
        }
        Person *person = [[Person alloc] init];
        person.name = (a % 2) == 0 ? @"志忠" : @"sir";
        person.age = @"23";
        NSDate *date = [NSDate date];
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        NSString *strDate = [dateFormatter stringFromDate:date];
        person.time = strDate;
        [array addObject:person];
        a++;
    }];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(15 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        for (NSInteger i = 0; i < 30; i ++) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                
            });
        }
        for (NSInteger i = 0; i < array.count; i ++) {
            NSLog(@"%@",[array[i] time]);
        }
        NSArray *sortedArray = [array sortedArrayUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
            Person *pModel1 = obj1;
            Person *pModel2 = obj2;
            
            //入职时间
            
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            
            [dateFormatter setDateFormat: @"yyyy-MM-dd HH:mm:ss"];
            
            NSDate *date1= [dateFormatter dateFromString:pModel1.time];
            NSDate *date2= [dateFormatter dateFromString:pModel2.time];
            
            if (date1 == [date1 earlierDate: date2]) { //不使用intValue比较无效
                
                return NSOrderedDescending;//降序
                
            }else if (date1 == [date1 laterDate: date2]) {
                return NSOrderedAscending;//升序
                
            }else{
                return NSOrderedSame;//相等
            }
        }];
        NSMutableDictionary *resultDict = [NSMutableDictionary dictionary];
        for (NSInteger i = 0; i < sortedArray.count; i ++) {
            Person *onePerson = sortedArray[i];
            NSString *oneTag = [NSString stringWithFormat:@"%@%@",onePerson.name,onePerson.age];
            for (NSInteger j = i + 1; j < sortedArray.count; j++) {
                Person *twoPerson = sortedArray[j];
                NSString *twoTag = [NSString stringWithFormat:@"%@%@",twoPerson.name,twoPerson.age];
                if ([oneTag isEqualToString:twoTag]) {
                    //                如果你按照时间降序你就删除onePerson，升序删除twoperson
                    [resultDict setObject:twoPerson forKey:onePerson.name];
                }
            }
        }
        NSLog(@"-----");
        NSLog(@"%@,%@",[resultDict[@"sir"] time], [resultDict[@"志忠"] time]);
    });

}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
